// scripts.js
function scrollToSection(event) {
    event.preventDefault();
    const targetId = event.target.getAttribute("href").substring(1);
    const targetElement = document.getElementById(targetId);
    let scrollPosition;

    if (targetId === 'ajuda') {
        scrollPosition = document.body.scrollHeight * 0.8;
    } else if (targetId === 'sobre') {
        scrollPosition = document.body.scrollHeight * 0.7;
    } else {
        scrollPosition = targetElement.offsetTop;
    }
    
    window.scroll({
        top: scrollPosition,
        behavior: "smooth"
    });
}

document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', scrollToSection);
    });
});

let loginAttempts = 0;

function login() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const errorMsg = document.getElementById('error-msg');
    const forgotPasswordBtn = document.getElementById('forgot-password-btn');
    const recoverPasswordDiv = document.getElementById('recover-password');

    if (email === 'herivelton@gmail.com' && password === 'heri123') {
        localStorage.setItem('user', 'Herivelton');
        window.location.href = 'index2.html';
    } else {
        loginAttempts++;
        errorMsg.textContent = 'Senha incorreta';
        errorMsg.style.display = 'block';

        if (loginAttempts >= 2) {
            forgotPasswordBtn.style.display = 'block';
        }
    }
}

function showRecoverPassword() {
    const recoverPasswordDiv = document.getElementById('recover-password');
    recoverPasswordDiv.style.display = 'block';
}

function sendRecoverEmail() {
    const recoverEmail = document.getElementById('recover-email').value;
    const recoverMsg = document.getElementById('recover-msg');
    const errorMsg = document.getElementById('error-msg');
    const forgotPasswordBtn = document.getElementById('forgot-password-btn');
    const recoverPasswordDiv = document.getElementById('recover-password');

    if (recoverEmail === 'angelina@gmail.com') {
        recoverMsg.textContent = 'E-mail de recuperação de senha enviado com sucesso';
        recoverMsg.style.display = 'block';
    } else {
        recoverMsg.textContent = 'E-mail não encontrado.';
        recoverMsg.style.display = 'block';
    }

    errorMsg.style.display = 'none';
    forgotPasswordBtn.style.display = 'none';
    recoverPasswordDiv.style.display = 'none';
}


function toggleDriverFields() {
    const userType = document.getElementById('userType').value;
    const driverFields = document.querySelector('.driver-fields');
    if (userType === 'motorista') {
        driverFields.style.display = 'block';
    } else {
        driverFields.style.display = 'none';
    }
}

function toggleDriverFields() {
    const userType = document.getElementById('userType').value;
    const driverFields = document.querySelector('.driver-fields');
    if (userType === 'motorista') {
        driverFields.style.display = 'block';
    } else {
        driverFields.style.display = 'none';
    }
}

function toggleDriverFields() {
    const userType = document.getElementById('userType').value;
    const driverFields = document.querySelector('.driver-fields');
    if (userType === 'motorista') {
        driverFields.style.display = 'block';
    } else {
        driverFields.style.display = 'none';
    }
}

function alternarCamposMotorista() {
    const tipoUsuario = document.getElementById('tipoUsuario').value;
    const camposMotorista = document.querySelector('.campos-motorista');
    if (tipoUsuario === 'motorista') {
        camposMotorista.style.display = 'block';
    } else {
        camposMotorista.style.display = 'none';
    }
}

window.addEventListener('DOMContentLoaded', (event) => {
    const anoAtual = new Date().getFullYear();
    const selectAnoCarro = document.getElementById('anoCarro');
    for (let ano = anoAtual; ano >= anoAtual - 40; ano--) {
        const option = document.createElement('option');
        option.value = ano;
        option.textContent = ano;
        selectAnoCarro.appendChild(option);
    }
});

document.addEventListener('input', function (event) {
    if (event.target.placeholder === 'Telefone') {
        event.target.value = event.target.value.replace(/[^\d()\- ]/g, '').slice(0, 15);
    } else if (event.target.placeholder === 'Seu R.A') {
        event.target.value = event.target.value.replace(/\D/g, '').slice(0, 9);
    }
});
